#include "CB_Task_1_Predef.h"
extern unsigned int color_sensor_pulse_count;

void forward_wls(unsigned char node);
void left_turn_wls(void);
void right_turn_wls(void);
void e_shape(void);
void Task_1_1(void);
void Task_1_2(void);

